﻿using System;
using ClosedXML.Excel;
using PdfSharpCore.Drawing;
using PdfSharpCore.Pdf;

namespace CreateForm
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("PDF Creation on-going!");

            // Specify the path to your Excel file and the desired output PDF file
            string excelFile = args[0]; //@"C:\Users\aa10180\Documents\XL2PDF\Format.xlsx";
            string outputPdf = args[1]; //@"C:\Users\aa10180\Documents\XL2PDF\output.pdf";

            // Specify the range of cells to include in the PDF (e.g., "A1:F10")
            string range = args[2]; //"A1:F12";

            XL2PDF(excelFile, outputPdf, range);
            Console.WriteLine("Done");
        }

        static void XL2PDF(string excelFile, string outputPdf, string range )
        {

            // Load the Excel workbook
            using (XLWorkbook workbook = new XLWorkbook(excelFile))
            {
                // Select the first worksheet
                IXLWorksheet worksheet = workbook.Worksheet(1);

                // Create a PDF document
                PdfDocument pdf = new PdfDocument();

                // Create a new page in the PDF
                PdfPage page = pdf.AddPage();

                // Get the XGraphics object for the page
                XGraphics gfx = XGraphics.FromPdfPage(page);

                // Get the range of cells to include
                IXLRange cellsRange = worksheet.Range(range);

                // Iterate over each cell in the range
                foreach (IXLCell cell in cellsRange.Cells())
                {
                    // Get the cell value
                    string cellValue = cell.Value.ToString();

                    // Get the text alignment of the cell
                    XStringAlignment alignment = XStringAlignment.Near;
                    switch (cell.Style.Alignment.Horizontal)
                    {
                        case XLAlignmentHorizontalValues.Center:
                            alignment = XStringAlignment.Center;
                            break;
                        case XLAlignmentHorizontalValues.Right:
                            alignment = XStringAlignment.Far;
                            break;
                    }

                    // Get the font color of the cell
                    XColor fontColor = XColor.Empty;
                    if (cell.Style.Font.FontColor.ColorType == XLColorType.Color)
                        fontColor = XColor.FromArgb(cell.Style.Font.FontColor.Color.ToArgb());

                    // Get the font style and size of the cell
                    XFontStyle fontStyle = XFontStyle.Regular;
                    if (cell.Style.Font.Bold)
                        fontStyle |= XFontStyle.Bold;
                    if (cell.Style.Font.Italic)
                        fontStyle |= XFontStyle.Italic;
                    if (cell.Style.Font.Strikethrough)
                        fontStyle |= XFontStyle.Strikeout;
                    if (cell.Style.Font.Underline != XLFontUnderlineValues.None)
                        fontStyle |= XFontStyle.Underline;

                    double fontSize = cell.Style.Font.FontSize;

                    // Get the font and background color of the cell
                    XFont font = new XFont(cell.Style.Font.FontName, fontSize, fontStyle);
                    XBrush background = new XSolidBrush(XColor.FromArgb(cell.Style.Fill.BackgroundColor.Color.ToArgb()));

                    // Get the borders of the cell
                    XLBorderStyleValues borderLeft = cell.Style.Border.LeftBorder;
                    XLBorderStyleValues borderTop = cell.Style.Border.TopBorder;
                    XLBorderStyleValues borderRight = cell.Style.Border.RightBorder;
                    XLBorderStyleValues borderBottom = cell.Style.Border.BottomBorder;

                    // Draw the cell background
                    XRect cellRect = new XRect(cell.Address.ColumnNumber * 50, cell.Address.RowNumber * 20, 50, 20);
                    gfx.DrawRectangle(background, cellRect);

                    // Draw the cell value with formatting
                    XStringFormat format = new XStringFormat();
                    format.Alignment = alignment;
                    format.LineAlignment = XLineAlignment.Center;

                    // Set the font color
                    XBrush fontBrush = new XSolidBrush(fontColor);

                    // Draw the cell value with formatting
                    gfx.DrawString(cellValue, font, fontBrush, cellRect, format);

                    // Draw the cell borders
                    XPen borderPen = new XPen(XColors.Black);
                    if (borderLeft != XLBorderStyleValues.None)
                        gfx.DrawLine(borderPen, cellRect.Left, cellRect.Top, cellRect.Left, cellRect.Bottom);
                    if (borderTop != XLBorderStyleValues.None)
                        gfx.DrawLine(borderPen, cellRect.Left, cellRect.Top, cellRect.Right, cellRect.Top);
                    if (borderRight != XLBorderStyleValues.None)
                        gfx.DrawLine(borderPen, cellRect.Right, cellRect.Top, cellRect.Right, cellRect.Bottom);
                    if (borderBottom != XLBorderStyleValues.None)
                        gfx.DrawLine(borderPen, cellRect.Left, cellRect.Bottom, cellRect.Right, cellRect.Bottom);
                }


                // Save the PDF document
                pdf.Save(outputPdf);
            }

        }
    }

}

